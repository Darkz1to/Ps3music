// Gera uma previa da tela no PC:  gcc tools/preview.c -Isource -lm -o preview && ./preview > preview.ppm
#include "../source/ui.c"
#include "../source/screen.c"
int main(int argc, char **argv) {
    int w = argc > 1 ? atoi(argv[1]) : 1280, h = argc > 2 ? atoi(argv[2]) : 720;
    static Track t[40]; const char *names[] = {"Linkin Park - Numb", "Imagine Dragons - Believer", "Charlie Brown Jr. - Zóio de Lula",
        "Legião Urbana - Tempo Perdido", "Matanza - Ela Roubou Meu Coração", "Racionais MC's - Diário de um Detento",
        "Djavan - Oceano", "Skank - Garota Nacional", "Pitty - Máscara", "NX Zero - Razões e Emoções", "Los Hermanos - Anna Júlia",
        "Natiruts - Quero Ser Feliz Também", "Capital Inicial - Natasha", "Engenheiros do Hawaii - Infinita Highway",
        "Oasis - Wonderwall", "Gorillaz - Feel Good Inc", "Rammstein - Du Hast", "Nirvana - Come As You Are"};
    int n = sizeof names / sizeof *names;
    for (int i = 0; i < n; i++) { snprintf(t[i].name, 200, "%s", names[i]); t[i].is_mp3 = i % 5 != 4; }
    View v = {t, n, 4, 0, 3, 0, 80, 83.0, 213.0, "/dev_hdd0/data/musics", NULL};
    Canvas c = {malloc((size_t)w * h * 4), w, h};
    screen_draw(&c, &v);
    printf("P6\n%d %d\n255\n", w, h);
    for (int i = 0; i < w * h; i++) { putchar(c.px[i] >> 16); putchar(c.px[i] >> 8); putchar(c.px[i]); }
    return 0;
}
