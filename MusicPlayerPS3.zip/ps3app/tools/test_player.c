// Teste no PC da logica do player (anel de audio simulado): gera WAV 44,1 kHz e confere a saida em 48 kHz.
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#define _GNU_SOURCE
#include <sys/mman.h>
#include <ppu-types.h>
#include <audio/audio.h>
#include "../source/player.h"
static u64 *pr; static float *ringmem;
#define ridx (*pr)
int audioInit(void){return 0;} int audioQuit(void){return 0;}
int audioPortOpen(audioPortParam*p,u32*n){*n=0;return 0;}
int audioGetPortConfig(u32 n,audioPortConfig*c){c->readIndex=(u32)(uintptr_t)pr;c->audioDataStart=(u32)(uintptr_t)ringmem;return 0;}
int audioPortStart(u32 n){return 0;} int audioPortStop(u32 n){return 0;} int audioPortClose(u32 n){return 0;}
static void w32(FILE*f,unsigned v){fputc(v,f);fputc(v>>8,f);fputc(v>>16,f);fputc(v>>24,f);} static void w16(FILE*f,unsigned v){fputc(v,f);fputc(v>>8,f);}
int main(void){
  void*m=mmap(NULL,1<<20,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANONYMOUS|MAP_32BIT,-1,0); pr=(u64*)m; ringmem=(float*)((char*)m+4096);
  // sandbox ponteiros de 32 bits: usa memoria baixa se possivel
  int rate=44100, n=rate; FILE*f=fopen("/tmp/t.wav","wb");
  fwrite("RIFF",1,4,f); w32(f,36+n*4); fwrite("WAVEfmt ",1,8,f); w32(f,16); w16(f,1); w16(f,2); w32(f,rate); w32(f,rate*4); w16(f,4); w16(f,16);
  fwrite("data",1,4,f); w32(f,n*4);
  for(int i=0;i<n;i++){ short s=(short)(20000*sin(2*M_PI*440*i/rate)); w16(f,(unsigned short)s); w16(f,(unsigned short)s);} fclose(f);
  if(player_init()){puts("init falhou");return 1;}
  int rc=player_play(getenv("TRACK")?getenv("TRACK"):"/tmp/t.wav", getenv("ISMP3")!=NULL); printf("play rc=%d dur=%.3f\n",rc,player_dur());
  player_set_volume(100);
  long frames=0, cross=0; float prev=0; int blocks=0;
  for(int it=0; it<2000 && blocks<400; it++){
    player_update();
    // dispositivo consome 1 bloco por iteracao se houver bloco pronto
    ridx=(ridx+1)%16; float*b=ringmem+(ridx*256*2);
    for(int i=0;i<256;i++){ float v=b[i*2]; if(prev<0&&v>=0&&frames>0) cross++; prev=v; frames++; }
    blocks++;
    if(player_ended() ) {printf("fim sinalizado apos %d blocos, pos=%.3f\n",blocks,player_pos());break;}
  }
  printf("quadros lidos=%ld  cruzamentos por zero=%ld (esperado ~440)  frames/48000=%.3f s\n",frames,cross,frames/48000.0);
  return 0;
}
