# Gera source/font8x16.h (Latin-1, 32..255) a partir da DejaVu Sans Mono
from PIL import Image, ImageDraw, ImageFont
f=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSansMono-Bold.ttf',13,layout_engine=ImageFont.Layout.BASIC)
rows=[]
out=[]
for cp in range(32,256):
    im=Image.new('L',(8,16),0); d=ImageDraw.Draw(im)
    d.fontmode='1'                     # sem antialias
    if not (127<=cp<=160): d.text((0,13),chr(cp),font=f,fill=255,anchor='ls')
    g=[]
    for y in range(16):
        v=0
        for x in range(8):
            if im.getpixel((x,y))>127: v|=0x80>>x
        g.append(v)
    out.append((cp,g))
with open('source/font8x16.h','w') as fh:
    fh.write('// Fonte bitmap 8x16, Latin-1 (32..255), gerada de DejaVu Sans Mono Bold (licença livre Bitstream Vera/DejaVu).\n')
    fh.write('// Gerada por tools/genfont.py - bit 7 = pixel mais à esquerda.\n#pragma once\n')
    fh.write('static const unsigned char font8x16[224][16] = {\n')
    for cp,g in out:
        fh.write('  {'+','.join('0x%02X'%b for b in g)+'}, /* %d */\n'%cp)
    fh.write('};\n')
print('ok')
# prévia
im=Image.new('RGB',(8*40,16*3),(0,0,0)); 
for r,t in enumerate(['Músicas ção ã é õ ü - Tocando: Ação','ABCDEFGHIJKLMNOPQRSTUVWXYZ 0123456789','abcdefghijklmnopqrstuvwxyz ./_()[]']):
    for i,ch in enumerate(t):
        cp=ord(ch)
        if 32<=cp<256:
            g=out[cp-32][1]
            for y in range(16):
                for x in range(8):
                    if g[y]&(0x80>>x): im.putpixel((i*8+x,r*16+y),(255,255,255))
im.resize((im.width*3,im.height*3),Image.NEAREST).save('/tmp/fontprev.png')
