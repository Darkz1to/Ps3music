# Music Player para PS3

Tela com a lista de músicas de `/dev_hdd0/data/musics`. Escolha com as setas e aperte **X** para tocar.
Veja `preview.png` para o visual (tema vermelho liquid glass).

## Controles
| Botão | Ação |
|---|---|
| Cima / Baixo | escolher a faixa (segure para rolar) |
| Esquerda / Direita | pular uma página da lista |
| X | tocar a faixa escolhida |
| O | parar |
| Triângulo | pausar / continuar |
| Quadrado | atualizar a lista (releitura da pasta) |
| L1 / R1 | volume - / + |

Ao terminar uma faixa, a próxima da lista toca sozinha. Para sair, use o botão PS.

## Formatos
- **WAV** PCM 16 bits (mono ou estéreo, qualquer taxa; é reamostrado para 48 kHz): funciona sem bibliotecas extras.
- **MP3**: decodificado pelo `minimp3` (um único arquivo, domínio público). O workflow baixa o `minimp3.h`
  para `source/` e o Makefile o liga sozinho. Se o arquivo não existir, os mp3 aparecem na lista, mas o app
  avisa que o MP3 não está habilitado. (Alternativa: `make MP3=1` usa a `libmpg123`, se o toolchain a tiver.)

## Compilar pelo celular (sem PC): GitHub Actions
Veja o arquivo `build.yml` que acompanha este projeto. Resumo: crie um repositório no GitHub, envie
`MusicPlayerPS3.zip` e o `build.yml` (movido para `.github/workflows/build.yml`), abra a aba Actions e rode
"Compilar MusicPlayer". Ao terminar, baixe o artefato `MusicPlayer` (contém o `MusicPlayer.pkg` e o `EBOOT.BIN`).

## Como compilar no PC
1. Tenha o ps3toolchain (PSL1GHT) instalado e `export PS3DEV=/usr/local/ps3dev` (ajuste o caminho).
2. Na pasta do projeto:
   - `make` gera `MusicPlayer.self`
   - `make pkg` gera `MusicPlayer.pkg`, com o `EBOOT.BIN` dentro, para instalar no PS3 com CFW/webMAN
   - `make MP3=1 pkg` faz o mesmo com suporte a MP3
3. Coloque as músicas em `/dev_hdd0/data/musics` (pode usar a aba Arquivos do PS3 Hub).

## Estrutura
- `source/main.c` - video, controle, lista de arquivos e laço principal
- `source/player.c` - saída de áudio, decodificação WAV/MP3, reamostragem
- `source/screen.c`, `source/ui.c` - desenho da tela (independente do PS3)
- `source/font8x16.h` - fonte bitmap Latin-1 (acentos), gerada por `tools/genfont.py`
- `tools/preview.c` - gera a prévia da tela no PC; `tools/test_player.c` - testa o player no PC

## Aviso
Este código **não foi compilado nem executado em um PS3**. Só foi verificado no PC: a tela (gerou `preview.png`)
e a lógica do player (reamostragem e anel de áudio, com 440 Hz saindo certo). As chamadas da API do PSL1GHT
(vídeo, áudio, controle) foram escritas a partir do padrão dos exemplos oficiais; se o compilador acusar algum
nome ou parâmetro diferente na sua versão do SDK, o ajuste costuma ser pequeno.
