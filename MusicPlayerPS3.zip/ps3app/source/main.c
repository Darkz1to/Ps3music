// MusicPlayer para PS3 (PSL1GHT)
// Tela com a lista de musicas de /dev_hdd0/data/musics: escolha com as setas e aperte X para tocar.
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <unistd.h>
#include <malloc.h>
#include <dirent.h>
#include <sys/stat.h>

#include <ppu-types.h>
#include <sysutil/video.h>
#include <sysutil/sysutil.h>
#include <rsx/gcm_sys.h>
#include <rsx/rsx.h>
#include <io/pad.h>

#include "screen.h"
#include "player.h"

#define MUSIC_DIR   "/dev_hdd0/data/musics"
#define MAX_TRACKS  2000
#define CB_SIZE     0x100000
#define HOST_SIZE   (32 * 1024 * 1024)

// ---------------- video (framebuffer duplo na RSX) ----------------
static gcmContextData *ctx;
static void *host_addr;
static u32 fb_w, fb_h, fb_pitch, fb_off[2];
static u32 *fb[2];
static int cur_fb, flip_pending;

static void init_screen(void) {
    host_addr = memalign(1024 * 1024, HOST_SIZE);
    rsxInit(&ctx, CB_SIZE, HOST_SIZE, host_addr);

    videoState st;
    videoGetState(0, 0, &st);
    videoResolution res;
    videoGetResolution(st.displayMode.resolution, &res);

    videoConfiguration vc;
    memset(&vc, 0, sizeof vc);
    vc.resolution = st.displayMode.resolution;
    vc.format = VIDEO_BUFFER_FORMAT_XRGB;
    vc.pitch = res.width * sizeof(u32);
    vc.aspect = st.displayMode.aspect;
    videoConfigure(0, &vc, NULL, 0);
    videoGetState(0, 0, &st);

    gcmSetFlipMode(GCM_FLIP_VSYNC);
    fb_w = res.width; fb_h = res.height; fb_pitch = res.width * sizeof(u32);
    for (int i = 0; i < 2; i++) {
        fb[i] = (u32 *)rsxMemalign(64, fb_h * fb_pitch);
        rsxAddressToOffset(fb[i], &fb_off[i]);
        gcmSetDisplayBuffer(i, fb_off[i], fb_pitch, fb_w, fb_h);
    }
    gcmResetFlipStatus();
}

static void wait_flip(void) {
    while (gcmGetFlipStatus() != 0) usleep(200);
    gcmResetFlipStatus();
}

static void flip_to(int id) {                            // enfileira a troca de buffer (a espera e feita antes de desenhar)
    if (gcmSetFlip(ctx, id) == 0) {
        rsxFlushBuffer(ctx);
        gcmSetWaitFlip(ctx);
        flip_pending = 1;
    }
}

// ---------------- encerramento pelo menu do PS ----------------
static int running = 1;
static void sysutil_cb(u64 status, u64 param, void *usrdata) {
    (void)param; (void)usrdata;
    if (status == SYSUTIL_EXIT_GAME) running = 0;
}

// ---------------- controle ----------------
enum { B_UP = 1, B_DOWN = 2, B_LEFT = 4, B_RIGHT = 8, B_CROSS = 16, B_CIRCLE = 32, B_SQUARE = 64,
       B_TRI = 128, B_L1 = 256, B_R1 = 512 };

static unsigned read_pad(void) {
    padInfo info; padData d; unsigned b = 0;
    ioPadGetInfo(&info);
    for (int i = 0; i < MAX_PADS; i++) {
        if (!info.status[i]) continue;
        ioPadGetData(i, &d);
        if (d.BTN_UP) b |= B_UP;
        if (d.BTN_DOWN) b |= B_DOWN;
        if (d.BTN_LEFT) b |= B_LEFT;
        if (d.BTN_RIGHT) b |= B_RIGHT;
        if (d.BTN_CROSS) b |= B_CROSS;
        if (d.BTN_CIRCLE) b |= B_CIRCLE;
        if (d.BTN_SQUARE) b |= B_SQUARE;
        if (d.BTN_TRIANGLE) b |= B_TRI;
        if (d.BTN_L1) b |= B_L1;
        if (d.BTN_R1) b |= B_R1;
    }
    return b;
}

// ---------------- lista de musicas ----------------
static Track *tracks;
static int ntracks;

static int cmp_track(const void *a, const void *b) {
    return strcasecmp(((const Track *)a)->name, ((const Track *)b)->name);
}

static int ext_kind(const char *n) {                    // 1 = mp3, 0 = wav, -1 = outro
    const char *dot = strrchr(n, '.');
    if (!dot) return -1;
    if (!strcasecmp(dot, ".mp3")) return 1;
    if (!strcasecmp(dot, ".wav")) return 0;
    return -1;
}

static int scan_dir(void) {
    ntracks = 0;
    DIR *d = opendir(MUSIC_DIR);
    if (!d) return -1;
    struct dirent *e;
    while ((e = readdir(d)) && ntracks < MAX_TRACKS) {
        if (e->d_name[0] == '.') continue;
        int k = ext_kind(e->d_name);
        if (k < 0) continue;
        Track *t = &tracks[ntracks];
        snprintf(t->path, sizeof t->path, "%s/%s", MUSIC_DIR, e->d_name);
        snprintf(t->name, sizeof t->name, "%s", e->d_name);
        *strrchr(t->name, '.') = 0;
        t->is_mp3 = (unsigned char)k;
        ntracks++;
    }
    closedir(d);
    qsort(tracks, ntracks, sizeof(Track), cmp_track);
    return 0;
}

int main(void) {
    tracks = (Track *)calloc(MAX_TRACKS, sizeof(Track));
    sysUtilRegisterCallback(0, sysutil_cb, NULL);
    ioPadInit(7);
    init_screen();
    int audio_err = player_init();

    Canvas cv = { (uint32_t *)memalign(16, (size_t)fb_w * fb_h * 4), (int)fb_w, (int)fb_h };
    int rows = screen_rows(cv.w, cv.h);

    int scan_rc = scan_dir();
    View v = { tracks, ntracks, 0, 0, -1, 0, 80, 0, 0, MUSIC_DIR, NULL };
    char msg[160] = "";
    if (scan_rc < 0) snprintf(msg, sizeof msg, "Pasta não encontrada. Crie %s e coloque suas músicas nela.", MUSIC_DIR);
    else if (audio_err) snprintf(msg, sizeof msg, "Falha ao iniciar o áudio (erro %d).", audio_err);
    v.msg = msg;

    unsigned prev = 0;
    int hold_up = 0, hold_dn = 0, dirty = 1, shown_sec = -1;

    while (running) {
        sysUtilCheckCallback();
        unsigned b = read_pad(), press = b & ~prev;

        // setas: toque simples + repeticao ao segurar
        int move = 0;
        if (press & B_UP) { move = -1; hold_up = 0; } else if (b & B_UP) { if (++hold_up > 14 && hold_up % 3 == 0) move = -1; }
        if (press & B_DOWN) { move = 1; hold_dn = 0; } else if (b & B_DOWN) { if (++hold_dn > 14 && hold_dn % 3 == 0) move = 1; }
        if (press & B_LEFT) move = -rows;
        if (press & B_RIGHT) move = rows;
        if (move && ntracks) {
            v.sel += move;
            if (v.sel < 0) v.sel = 0;
            if (v.sel >= ntracks) v.sel = ntracks - 1;
            dirty = 1;
        }

        if ((press & B_CROSS) && ntracks) {                 // tocar a faixa selecionada
            int rc = player_play(tracks[v.sel].path, tracks[v.sel].is_mp3);
            if (rc == PLAYER_OK) { v.playing = v.sel; v.paused = 0; msg[0] = 0; }
            else { v.playing = -1; snprintf(msg, sizeof msg, "%s", player_error_text(rc)); }
            dirty = 1;
        }
        if ((press & B_CIRCLE) && v.playing >= 0) { player_stop(); v.playing = -1; msg[0] = 0; dirty = 1; }
        if ((press & B_TRI) && v.playing >= 0) { v.paused = !v.paused; player_set_paused(v.paused); dirty = 1; }
        if (press & B_SQUARE) {                              // atualizar a lista
            char playing_path[400] = "";
            if (v.playing >= 0) snprintf(playing_path, sizeof playing_path, "%s", tracks[v.playing].path);
            scan_rc = scan_dir();
            v.count = ntracks; v.playing = -1;
            for (int i = 0; i < ntracks && playing_path[0]; i++)
                if (!strcmp(tracks[i].path, playing_path)) v.playing = i;
            if (v.playing < 0) player_stop();
            if (v.sel >= ntracks) v.sel = ntracks ? ntracks - 1 : 0;
            if (scan_rc < 0) snprintf(msg, sizeof msg, "Pasta não encontrada: %s", MUSIC_DIR); else msg[0] = 0;
            dirty = 1;
        }
        if (press & B_L1) { player_set_volume(player_get_volume() - 5); dirty = 1; }
        if (press & B_R1) { player_set_volume(player_get_volume() + 5); dirty = 1; }
        prev = b;

        // rolagem: mantem a selecao visivel
        if (v.sel < v.top) v.top = v.sel;
        if (v.sel >= v.top + rows) v.top = v.sel - rows + 1;
        if (v.top < 0) v.top = 0;

        player_update();

        // fim da faixa: segue para a proxima
        if (player_ended() && v.playing >= 0) {
            int nx = v.playing + 1;
            if (nx < ntracks && player_play(tracks[nx].path, tracks[nx].is_mp3) == PLAYER_OK) { v.playing = nx; v.sel = nx; }
            else { v.playing = -1; v.paused = 0; }
            dirty = 1;
        }

        // atualiza o relogio uma vez por segundo
        v.volume = player_get_volume();
        v.pos = player_pos(); v.dur = player_dur();
        if (v.playing >= 0 && (int)v.pos != shown_sec) { shown_sec = (int)v.pos; dirty = 1; }

        if (dirty) {                                         // so redesenha quando algo mudou
            v.count = ntracks;
            screen_draw(&cv, &v);
            if (flip_pending) { wait_flip(); flip_pending = 0; }
            memcpy(fb[cur_fb], cv.px, (size_t)fb_w * fb_h * 4);
            flip_to(cur_fb);
            cur_fb ^= 1;
            dirty = 0;
        }
        usleep(8000);
    }

    player_close();
    ioPadEnd();
    gcmSetWaitFlip(ctx);
    rsxFinish(ctx, 1);
    sysUtilUnregisterCallback(0);
    return 0;
}
