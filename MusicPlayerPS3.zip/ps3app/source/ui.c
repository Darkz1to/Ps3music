#include "ui.h"
#include "font8x16.h"
#include <math.h>
#include <string.h>

static inline uint32_t mix(uint32_t dst, uint32_t src, int a) {   // a: 0..255
    if (a <= 0) return dst;
    if (a >= 255) return src;
    int dr = (dst >> 16) & 255, dg = (dst >> 8) & 255, db = dst & 255;
    int sr = (src >> 16) & 255, sg = (src >> 8) & 255, sb = src & 255;
    return RGB(dr + (sr - dr) * a / 255, dg + (sg - dg) * a / 255, db + (sb - db) * a / 255);
}

void ui_rect(Canvas *c, int x, int y, int w, int h, uint32_t col) {
    int x0 = x < 0 ? 0 : x, y0 = y < 0 ? 0 : y;
    int x1 = x + w > c->w ? c->w : x + w, y1 = y + h > c->h ? c->h : y + h;
    for (int j = y0; j < y1; j++)
        for (int i = x0; i < x1; i++) c->px[j * c->w + i] = col;
}

// cobertura (0..255) do pixel (px,py) dentro de um retangulo arredondado inset pelo valor "in"
static int rr_cov(float px, float py, float x, float y, float w, float h, float r) {
    float cx = px + 0.5f, cy = py + 0.5f;
    float dx = 0, dy = 0;
    if (cx < x + r) dx = (x + r) - cx; else if (cx > x + w - r) dx = cx - (x + w - r);
    if (cy < y + r) dy = (y + r) - cy; else if (cy > y + h - r) dy = cy - (y + h - r);
    if (cx < x || cx > x + w || cy < y || cy > y + h) return 0;
    if (dx <= 0 || dy <= 0) return 255;
    float d = sqrtf(dx * dx + dy * dy);
    float k = r - d + 0.5f;
    return k <= 0 ? 0 : (k >= 1 ? 255 : (int)(k * 255));
}

void ui_panel(Canvas *c, int x, int y, int w, int h, int radius,
              uint32_t fill, int fill_a, uint32_t border, int border_a) {
    int x0 = x < 0 ? 0 : x, y0 = y < 0 ? 0 : y;
    int x1 = x + w > c->w ? c->w : x + w, y1 = y + h > c->h ? c->h : y + h;
    for (int j = y0; j < y1; j++) {
        for (int i = x0; i < x1; i++) {
            int co = rr_cov(i, j, x, y, w, h, radius);
            if (!co) continue;
            int ci = rr_cov(i, j, x + 2, y + 2, w - 4, h - 4, radius > 2 ? radius - 2 : 0);
            // brilho no topo (efeito vidro): fica mais claro nos primeiros pixels
            int gloss = j - y < h / 3 ? 18 - (18 * (j - y)) / (h / 3 + 1) : 0;
            uint32_t p = c->px[j * c->w + i];
            p = mix(p, fill, fill_a * ci / 255);
            if (gloss) p = mix(p, RGB(255, 255, 255), gloss * ci / 255);
            p = mix(p, border, border_a * (co - ci) / 255);
            c->px[j * c->w + i] = p;
        }
    }
}

static int next_cp(const unsigned char **pp) {
    const unsigned char *p = *pp;
    int c = *p++;
    if (c < 0x80) { *pp = p; return c; }
    int n = 0, cp = 0;
    if ((c & 0xE0) == 0xC0) { n = 1; cp = c & 0x1F; }
    else if ((c & 0xF0) == 0xE0) { n = 2; cp = c & 0x0F; }
    else if ((c & 0xF8) == 0xF0) { n = 3; cp = c & 0x07; }
    else { *pp = p; return '?'; }
    while (n-- > 0 && (*p & 0xC0) == 0x80) cp = (cp << 6) | (*p++ & 0x3F);
    *pp = p;
    return cp;
}

#define MAXG 600
static int to_glyphs(const char *s, unsigned char *g) {
    const unsigned char *p = (const unsigned char *)s;
    int n = 0;
    while (*p && n < MAXG) {
        int cp = next_cp(&p);
        if (cp < 32 || cp == 127) continue;
        if (cp > 255) cp = '?';
        g[n++] = (unsigned char)cp;
    }
    return n;
}

int ui_text_width(const char *s, int scale) {
    unsigned char g[MAXG];
    return to_glyphs(s, g) * 8 * scale;
}

static void glyph(Canvas *c, int x, int y, int scale, uint32_t col, unsigned char ch) {
    const unsigned char *rows = font8x16[ch - 32];
    for (int j = 0; j < 16; j++) {
        unsigned b = rows[j];
        if (!b) continue;
        for (int i = 0; i < 8; i++)
            if (b & (0x80 >> i)) ui_rect(c, x + i * scale, y + j * scale, scale, scale, col);
    }
}

int ui_text(Canvas *c, int x, int y, int scale, uint32_t col, const char *s, int maxw) {
    unsigned char g[MAXG + 4];
    int n = to_glyphs(s, g);
    int cw = 8 * scale;
    if (maxw > 0 && n * cw > maxw) {
        int keep = maxw / cw - 3;
        if (keep < 0) keep = 0;
        n = keep;
        g[n++] = '.'; g[n++] = '.'; g[n++] = '.';
    }
    for (int i = 0; i < n; i++) {                                    // sombra para dar leitura sobre o fundo
        glyph(c, x + i * cw + scale, y + scale, scale, RGB(20, 0, 4), g[i]);
    }
    for (int i = 0; i < n; i++) glyph(c, x + i * cw, y, scale, col, g[i]);
    return n * cw;
}
