// ui.h - desenho 2D simples em um buffer XRGB (sem depender de nada do PS3)
#pragma once
#include <stdint.h>

typedef struct { uint32_t *px; int w, h; } Canvas;

#define RGB(r, g, b) ((((uint32_t)(r)) << 16) | (((uint32_t)(g)) << 8) | ((uint32_t)(b)))

void ui_rect(Canvas *c, int x, int y, int w, int h, uint32_t col);
// Painel de vidro: preenchimento translucido + borda, com cantos arredondados.
void ui_panel(Canvas *c, int x, int y, int w, int h, int radius,
              uint32_t fill, int fill_a, uint32_t border, int border_a);
int  ui_text_width(const char *utf8, int scale);
// Desenha texto (UTF-8 -> Latin-1). maxw > 0 corta com "..." se passar da largura.
// Retorna a largura desenhada.
int  ui_text(Canvas *c, int x, int y, int scale, uint32_t col, const char *utf8, int maxw);
