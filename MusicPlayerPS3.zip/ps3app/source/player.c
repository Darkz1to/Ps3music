#include "player.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <ppu-types.h>
#include <audio/audio.h>
#if defined(USE_MPG123)
#include <mpg123.h>
#elif defined(USE_MINIMP3)
#define MINIMP3_IMPLEMENTATION
#define MINIMP3_ONLY_MP3
#define MINIMP3_NO_SIMD
#include "minimp3.h"          // decodificador de MP3 em um unico arquivo (dominio publico), baixado pelo workflow
#endif

#define OUT_RATE   48000                 // a saida de audio do PS3 e fixa em 48 kHz
#define NUM_BLOCKS 16                    // anel de 16 blocos de 256 amostras (~85 ms)

// ---------------- saida de audio ----------------
static audioPortConfig cfg;
static u32 port;
static int audio_ok;
static u32 next_blk;
static volatile u64 *read_idx;
static float *ring;
static long long produced;               // quadros entregues ao anel desde o inicio da faixa
static int volume = 80;
static int paused;
static int ended_flag;

// ---------------- decodificador ----------------
typedef enum { DEC_NONE, DEC_WAV, DEC_MP3 } DecType;
static struct {
    DecType type;
    FILE *fp;
    int finished;
    double dur;
    // WAV
    int channels;
    unsigned rate;
    long remaining;                      // bytes de dados que faltam
    unsigned char raw[8192];
    int nframes, pos;                    // quadros bufferizados / posicao
    float f0[2], f1[2];
    double frac, step;
    int primed;
#ifdef USE_MINIMP3
    mp3dec_t md;
    unsigned char *mbuf;
    long msize, mpos;
    short mpcm[MINIMP3_MAX_SAMPLES_PER_FRAME];
    int mcnt, mfpos, mch, mrate, mkbps;
#endif
#ifdef USE_MPG123
    mpg123_handle *mh;
    short pcm[2048 * 2];
    long filesize;
    int got_info;
#endif
} D;

static int (*src_next)(float *, float *);   // le o proximo quadro estereo da fonte atual (WAV ou MP3)

static unsigned rd16(const unsigned char *p) { return p[0] | (p[1] << 8); }
static unsigned rd32(const unsigned char *p) { return p[0] | (p[1] << 8) | (p[2] << 16) | ((unsigned)p[3] << 24); }

static void dec_close(void) {
    if (D.fp) fclose(D.fp);
#ifdef USE_MPG123
    if (D.mh) { mpg123_close(D.mh); mpg123_delete(D.mh); }
    D.mh = NULL;
#endif
    D.fp = NULL; D.type = DEC_NONE; D.finished = 0;
#ifdef USE_MINIMP3
    free(D.mbuf); D.mbuf = NULL;
#endif
}

static int wav_next(float *l, float *r);
static int wav_next_fwd(float *l, float *r) { return wav_next(l, r); }

static int wav_open(const char *path) {
    D.fp = fopen(path, "rb");
    if (!D.fp) return PLAYER_ERR_OPEN;
    unsigned char h[12];
    if (fread(h, 1, 12, D.fp) != 12 || memcmp(h, "RIFF", 4) || memcmp(h + 8, "WAVE", 4)) return PLAYER_ERR_FORMAT;
    int have_fmt = 0, bits = 0, tag = 0;
    for (;;) {
        unsigned char ch[8];
        if (fread(ch, 1, 8, D.fp) != 8) return PLAYER_ERR_FORMAT;
        unsigned sz = rd32(ch + 4);
        if (!memcmp(ch, "fmt ", 4)) {
            unsigned char f[16];
            if (sz < 16 || fread(f, 1, 16, D.fp) != 16) return PLAYER_ERR_FORMAT;
            tag = rd16(f); D.channels = rd16(f + 2); D.rate = rd32(f + 4); bits = rd16(f + 14);
            if (sz > 16) fseek(D.fp, (long)(sz - 16), SEEK_CUR);
            have_fmt = 1;
        } else if (!memcmp(ch, "data", 4)) {
            if (!have_fmt) return PLAYER_ERR_FORMAT;
            D.remaining = (long)sz;
            break;
        } else {
            fseek(D.fp, (long)((sz + 1) & ~1u), SEEK_CUR);
        }
    }
    if (tag != 1 || bits != 16 || (D.channels != 1 && D.channels != 2) || D.rate < 8000 || D.rate > 192000)
        return PLAYER_ERR_FORMAT;
    D.type = DEC_WAV;
    src_next = wav_next_fwd;
    D.nframes = D.pos = 0; D.primed = 0; D.frac = 0;
    D.step = (double)D.rate / OUT_RATE;
    D.dur = (double)D.remaining / (D.channels * 2) / D.rate;
    return PLAYER_OK;
}

static int wav_next(float *l, float *r) {
    if (D.pos >= D.nframes) {
        int bpf = D.channels * 2, want = (int)sizeof(D.raw) / bpf;
        if ((long)want * bpf > D.remaining) want = (int)(D.remaining / bpf);
        D.nframes = want > 0 ? (int)fread(D.raw, bpf, want, D.fp) : 0;
        D.remaining -= (long)D.nframes * bpf;
        D.pos = 0;
        if (D.nframes <= 0) return 0;
    }
    const unsigned char *p = D.raw + D.pos * D.channels * 2;
    short a = (short)rd16(p);
    short b = D.channels == 2 ? (short)rd16(p + 2) : a;
    *l = a / 32768.0f; *r = b / 32768.0f;
    D.pos++;
    return 1;
}

static int src_fill(float *out, int frames) {        // retorna quadros gerados (reamostra para 48 kHz se preciso)
    int n = 0;
    if (D.rate == OUT_RATE) {
        while (n < frames && src_next(&out[n * 2], &out[n * 2 + 1])) n++;
        return n;
    }
    if (!D.primed) {                                   // reamostragem linear para 48 kHz
        if (!src_next(&D.f0[0], &D.f0[1])) return 0;
        if (!src_next(&D.f1[0], &D.f1[1])) { D.f1[0] = D.f0[0]; D.f1[1] = D.f0[1]; }
        D.primed = 1;
    }
    while (n < frames) {
        float t = (float)D.frac;
        out[n * 2]     = D.f0[0] + (D.f1[0] - D.f0[0]) * t;
        out[n * 2 + 1] = D.f0[1] + (D.f1[1] - D.f0[1]) * t;
        n++;
        D.frac += D.step;
        while (D.frac >= 1.0) {
            D.frac -= 1.0;
            D.f0[0] = D.f1[0]; D.f0[1] = D.f1[1];
            if (!src_next(&D.f1[0], &D.f1[1])) return n;
        }
    }
    return n;
}

#ifdef USE_MINIMP3
static int mini_decode_next(void) {                    // decodifica o proximo quadro com audio; 0 = fim do arquivo
    for (;;) {
        if (D.mpos >= D.msize) return 0;
        mp3dec_frame_info_t fi;
        int s = mp3dec_decode_frame(&D.md, D.mbuf + D.mpos, (int)(D.msize - D.mpos), D.mpcm, &fi);
        if (fi.frame_bytes <= 0) return 0;
        D.mpos += fi.frame_bytes;
        if (s > 0) {
            D.mcnt = s; D.mfpos = 0; D.mch = fi.channels; D.mrate = fi.hz; D.mkbps = fi.bitrate_kbps;
            return 1;
        }
    }
}

static int mini_next(float *l, float *r) {
    if (D.mfpos >= D.mcnt && !mini_decode_next()) return 0;
    if (D.mch == 1) { *l = *r = D.mpcm[D.mfpos] / 32768.0f; }
    else { *l = D.mpcm[D.mfpos * 2] / 32768.0f; *r = D.mpcm[D.mfpos * 2 + 1] / 32768.0f; }
    D.mfpos++;
    return 1;
}

static int mini_open(const char *path) {
    D.fp = fopen(path, "rb");
    if (!D.fp) return PLAYER_ERR_OPEN;
    fseek(D.fp, 0, SEEK_END);
    long sz = ftell(D.fp);
    fseek(D.fp, 0, SEEK_SET);
    if (sz <= 0 || sz > 96L * 1024 * 1024) return PLAYER_ERR_FORMAT;
    D.mbuf = (unsigned char *)malloc((size_t)sz);
    if (!D.mbuf) return PLAYER_ERR_FORMAT;
    if (fread(D.mbuf, 1, (size_t)sz, D.fp) != (size_t)sz) return PLAYER_ERR_OPEN;
    fclose(D.fp); D.fp = NULL;
    D.msize = sz; D.mpos = 0; D.mcnt = D.mfpos = 0;
    mp3dec_init(&D.md);
    if (!mini_decode_next()) return PLAYER_ERR_FORMAT;   // le o 1o quadro: taxa, canais e bitrate
    D.mfpos = 0;                                         // ele sera tocado desde o inicio
    D.rate = (unsigned)D.mrate;
    D.step = (double)D.rate / OUT_RATE;
    D.dur = D.mkbps > 0 ? (double)sz * 8.0 / (D.mkbps * 1000.0) : 0.0;
    D.type = DEC_MP3; src_next = mini_next;
    D.primed = 0; D.frac = 0;
    return PLAYER_OK;
}
#endif

#ifdef USE_MPG123
static int mp3_open(const char *path) {
    static int inited;
    if (!inited) { if (mpg123_init() != MPG123_OK) return PLAYER_ERR_FORMAT; inited = 1; }
    int err = 0;
    D.mh = mpg123_new(NULL, &err);
    if (!D.mh) return PLAYER_ERR_FORMAT;
    mpg123_param(D.mh, MPG123_FLAGS, MPG123_FORCE_STEREO | MPG123_QUIET, 0);
    if (mpg123_open(D.mh, path) != MPG123_OK) return PLAYER_ERR_OPEN;
    mpg123_format_none(D.mh);
    mpg123_format(D.mh, OUT_RATE, MPG123_STEREO, MPG123_ENC_SIGNED_16);   // o mpg123 reamostra para 48 kHz
    D.fp = fopen(path, "rb");                           // so para medir o tamanho do arquivo
    D.filesize = 0;
    if (D.fp) { fseek(D.fp, 0, SEEK_END); D.filesize = ftell(D.fp); fclose(D.fp); D.fp = NULL; }
    D.type = DEC_MP3; D.got_info = 0; D.dur = 0;
    return PLAYER_OK;
}

static int mp3_fill(float *out, int frames) {
    int n = 0;
    while (n < frames) {
        size_t want = (size_t)(frames - n) * 4, got = 0;
        if (want > sizeof(D.pcm)) want = sizeof(D.pcm);
        int r = mpg123_read(D.mh, (unsigned char *)D.pcm, want, &got);
        int fr = (int)(got / 4);
        for (int i = 0; i < fr * 2; i++) out[n * 2 + i] = D.pcm[i] / 32768.0f;
        n += fr;
        if (!D.got_info && fr > 0) {                    // estima a duracao pelo bitrate do primeiro quadro
            struct mpg123_frameinfo fi;
            if (mpg123_info(D.mh, &fi) == MPG123_OK && fi.bitrate > 0 && D.filesize > 0)
                D.dur = (double)D.filesize * 8.0 / (fi.bitrate * 1000.0);
            D.got_info = 1;
        }
        if (r == MPG123_DONE || (r != MPG123_OK && r != MPG123_NEW_FORMAT)) break;
        if (fr == 0 && r == MPG123_OK) break;
    }
    return n;
}
#endif

// ---------------- API ----------------
int player_init(void) {
    if (audioInit() != 0) return -1;
    audioPortParam params;
    memset(&params, 0, sizeof params);
    params.numChannels = AUDIO_PORT_2CH;
    params.numBlocks = AUDIO_BLOCK_16;
    params.attr = 0;
    params.level = 1.0f;
    if (audioPortOpen(&params, &port) != 0) return -2;
    if (audioGetPortConfig(port, &cfg) != 0) return -3;
    read_idx = (volatile u64 *)(u64)cfg.readIndex;
    ring = (float *)(u64)cfg.audioDataStart;
    memset(ring, 0, (size_t)NUM_BLOCKS * AUDIO_BLOCK_SAMPLES * 2 * sizeof(float));
    next_blk = 1;
    if (audioPortStart(port) != 0) return -4;
    audio_ok = 1;
    return 0;
}

void player_close(void) {
    dec_close();
    if (audio_ok) { audioPortStop(port); audioPortClose(port); audioQuit(); audio_ok = 0; }
}

int player_play(const char *path, int is_mp3) {
    dec_close();
    produced = 0; ended_flag = 0; paused = 0;
    int r;
    if (is_mp3) {
#if defined(USE_MINIMP3)
        r = mini_open(path);
#elif defined(USE_MPG123)
        r = mp3_open(path);
#else
        return PLAYER_ERR_NOMP3;
#endif
    } else {
        r = wav_open(path);
    }
    if (r != PLAYER_OK) dec_close();
    return r;
}

void player_stop(void) { dec_close(); produced = 0; ended_flag = 0; paused = 0; }
void player_set_paused(int p) { paused = p; }
int  player_is_paused(void) { return paused; }
int  player_ended(void) { int e = ended_flag; ended_flag = 0; return e; }
void player_set_volume(int v) { volume = v < 0 ? 0 : (v > 100 ? 100 : v); }
int  player_get_volume(void) { return volume; }
double player_dur(void) { return D.type == DEC_NONE ? 0 : D.dur; }

double player_pos(void) {
    if (!audio_ok) return 0;
    long long pending = ((long long)next_blk + NUM_BLOCKS - (long long)(*read_idx % NUM_BLOCKS)) % NUM_BLOCKS;
    long long played = produced - pending * AUDIO_BLOCK_SAMPLES;
    return played > 0 ? (double)played / OUT_RATE : 0.0;
}

void player_update(void) {
    if (!audio_ok) return;
    static float tmp[AUDIO_BLOCK_SAMPLES * 2];
    for (;;) {
        u32 r = (u32)(*read_idx % NUM_BLOCKS);
        if ((next_blk + 1) % NUM_BLOCKS == r) break;     // anel cheio
        float *dst = ring + (size_t)next_blk * AUDIO_BLOCK_SAMPLES * 2;
        int n = 0;
        if (D.type != DEC_NONE && !paused) {
#if defined(USE_MPG123)
            if (D.type == DEC_WAV) n = src_fill(tmp, AUDIO_BLOCK_SAMPLES);
            else n = mp3_fill(tmp, AUDIO_BLOCK_SAMPLES);
#else
            n = src_fill(tmp, AUDIO_BLOCK_SAMPLES);
#endif
            produced += n;
            float g = volume / 100.0f; g *= g;           // curva quadratica: volume mais natural
            for (int i = 0; i < n * 2; i++) dst[i] = tmp[i] * g;
            if (n < AUDIO_BLOCK_SAMPLES) {               // acabou a faixa
                for (int i = n * 2; i < AUDIO_BLOCK_SAMPLES * 2; i++) dst[i] = 0;
                dec_close();
                ended_flag = 1;
            }
        } else {
            memset(dst, 0, AUDIO_BLOCK_SAMPLES * 2 * sizeof(float));
        }
        next_blk = (next_blk + 1) % NUM_BLOCKS;
    }
}

const char *player_error_text(int code) {
    switch (code) {
    case PLAYER_ERR_OPEN:   return "Não foi possível abrir o arquivo.";
    case PLAYER_ERR_FORMAT: return "Formato não suportado (use WAV PCM 16 bits ou MP3).";
    case PLAYER_ERR_NOMP3:  return "MP3 não habilitado nesta compilação (falta o minimp3.h).";
    default:                return "Erro desconhecido.";
    }
}
