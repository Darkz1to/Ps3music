// player.h - toca WAV (PCM 16 bits) e MP3 (se compilado com USE_MPG123) pela saida de audio do PS3
#pragma once

#define PLAYER_OK          0
#define PLAYER_ERR_OPEN    1
#define PLAYER_ERR_FORMAT  2
#define PLAYER_ERR_NOMP3   3

int         player_init(void);                 // 0 = ok
void        player_close(void);
int         player_play(const char *path, int is_mp3);
void        player_stop(void);
void        player_set_paused(int paused);
int         player_is_paused(void);
int         player_ended(void);                // 1 uma unica vez quando a faixa acaba
void        player_set_volume(int percent);    // 0..100
int         player_get_volume(void);
double      player_pos(void);                  // segundos
double      player_dur(void);                  // segundos (0 = desconhecida)
void        player_update(void);               // chamar em todo ciclo do loop principal
const char *player_error_text(int code);
