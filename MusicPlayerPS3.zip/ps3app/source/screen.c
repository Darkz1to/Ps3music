#include "screen.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct { int mx, ts, titleY, subY, listY, listH, rowH, nowY, nowH, footY, pad; } Layout;

static void layout(int w, int h, Layout *L) {
    L->ts = h >= 1000 ? 3 : 2;
    int line = 16 * L->ts;
    L->mx = w / 16;
    L->pad = L->ts * 4;
    L->titleY = h / 20;
    L->subY = L->titleY + 16 * (L->ts + 1) + L->ts * 4;
    L->listY = L->subY + line + L->ts * 8;
    L->rowH = line + L->ts * 4;
    L->footY = h - line - L->ts * 5;
    L->nowH = 2 * line + L->ts * 6 + 10 * L->ts + 2 * (L->ts * 6);
    L->nowY = L->footY - L->ts * 6 - L->nowH;
    L->listH = L->nowY - L->ts * 8 - L->listY;
}

int screen_rows(int w, int h) {
    Layout L; layout(w, h, &L);
    int r = (L.listH - 2 * L.pad) / L.rowH;
    return r < 1 ? 1 : r;
}

// ---- fundo "liquido": gradiente vinho + manchas vermelhas suaves (calculado uma vez) ----
static uint32_t *bg; static int bgw, bgh;

static void blob(float *acc, int w, int h, float cx, float cy, float rad, float r, float g, float b, float k) {
    int x0 = (int)(cx - rad), x1 = (int)(cx + rad), y0 = (int)(cy - rad), y1 = (int)(cy + rad);
    if (x0 < 0) x0 = 0;
    if (y0 < 0) y0 = 0;
    if (x1 > w) x1 = w;
    if (y1 > h) y1 = h;
    for (int y = y0; y < y1; y++)
        for (int x = x0; x < x1; x++) {
            float dx = x - cx, dy = y - cy, d2 = (dx * dx + dy * dy) / (rad * rad);
            if (d2 >= 1) continue;
            float t = (1 - d2); t = t * t * k;
            float *p = acc + (y * w + x) * 3;
            p[0] += r * t; p[1] += g * t; p[2] += b * t;
        }
}

static void make_bg(int w, int h) {
    bg = (uint32_t *)malloc((size_t)w * h * 4); bgw = w; bgh = h;
    float *acc = (float *)calloc((size_t)w * h * 3, sizeof(float));
    if (!bg || !acc) { free(acc); return; }
    for (int y = 0; y < h; y++) {
        float t = (float)y / h;
        for (int x = 0; x < w; x++) {
            float *p = acc + (y * w + x) * 3;
            p[0] = 46 - 34 * t; p[1] = 0 + 2 * t; p[2] = 9 - 5 * t;
        }
    }
    blob(acc, w, h, w * 0.12f, h * 0.10f, w * 0.42f, 255, 40, 70, 0.78f);
    blob(acc, w, h, w * 0.92f, h * 0.55f, w * 0.34f, 220, 20, 50, 0.70f);
    blob(acc, w, h, w * 0.45f, h * 1.02f, w * 0.30f, 255, 70, 90, 0.55f);
    blob(acc, w, h, w * 0.70f, h * 0.08f, w * 0.12f, 255, 110, 120, 0.45f);
    for (int i = 0; i < w * h; i++) {
        int r = (int)acc[i * 3], g = (int)acc[i * 3 + 1], b = (int)acc[i * 3 + 2];
        bg[i] = RGB(r > 255 ? 255 : r, g > 255 ? 255 : g, b > 255 ? 255 : b);
    }
    free(acc);
}

static void fmt_time(char *out, double s) {
    int t = s < 0 ? 0 : (int)s;
    sprintf(out, "%02d:%02d", t / 60, t % 60);
}

void screen_draw(Canvas *c, const View *v) {
    Layout L; layout(c->w, c->h, &L);
    int ts = L.ts, line = 16 * ts, w = c->w, h = c->h;
    const uint32_t WHITE = RGB(255, 244, 244), DIM = RGB(255, 190, 198), AMBER = RGB(255, 205, 110);

    if (!bg || bgw != w || bgh != h) { free(bg); bg = NULL; make_bg(w, h); }
    if (bg) memcpy(c->px, bg, (size_t)w * h * 4); else ui_rect(c, 0, 0, w, h, RGB(30, 0, 6));

    // cabecalho
    ui_text(c, L.mx, L.titleY, ts + 1, WHITE, "Músicas", 0);
    char sub[480];
    snprintf(sub, sizeof sub, "%s  -  %d %s", v->dir ? v->dir : "", v->count, v->count == 1 ? "faixa" : "faixas");
    ui_text(c, L.mx, L.subY, ts, DIM, sub, w - 2 * L.mx);

    // lista
    int px = L.mx, pw = w - 2 * L.mx;
    ui_panel(c, px, L.listY, pw, L.listH, ts * 8, RGB(255, 60, 80), 34, RGB(255, 200, 205), 95);
    int rows = screen_rows(w, h);
    if (v->count == 0) {
        ui_text(c, px + L.pad * 3, L.listY + L.pad * 3, ts, WHITE, "Nenhuma música encontrada.", pw - 6 * L.pad);
        ui_text(c, px + L.pad * 3, L.listY + L.pad * 3 + line + ts * 4, ts, DIM,
                "Coloque arquivos .mp3 ou .wav na pasta acima e aperte Quadrado.", pw - 6 * L.pad);
    }
    int textw = pw - 4 * L.pad - 6 * ts - 8 * ts * 5;           // espaco do nome
    for (int r = 0; r < rows; r++) {
        int i = v->top + r;
        if (i >= v->count) break;
        int ry = L.listY + L.pad + r * L.rowH;
        const Track *t = &v->tracks[i];
        if (i == v->sel)
            ui_panel(c, px + L.pad, ry, pw - 2 * L.pad - 10 * ts, L.rowH - ts, ts * 5,
                     RGB(255, 40, 70), 150, RGB(255, 230, 232), 150);
        int ty = ry + (L.rowH - line) / 2;
        int isplay = (i == v->playing);
        ui_text(c, px + L.pad * 2, ty, ts, isplay ? WHITE : (i == v->sel ? WHITE : DIM),
                isplay ? (v->paused ? "||" : ">") : "", 0);
        ui_text(c, px + L.pad * 2 + 8 * ts * 3, ty, ts, isplay ? WHITE : (i == v->sel ? WHITE : DIM), t->name, textw);
        ui_text(c, px + pw - L.pad * 3 - 10 * ts - 8 * ts * 3, ty, ts, isplay ? WHITE : DIM, t->is_mp3 ? "MP3" : "WAV", 0);
    }
    if (v->count > rows) {                                        // barra de rolagem
        int tx = px + pw - L.pad - 6 * ts, ty0 = L.listY + L.pad, th = L.listH - 2 * L.pad;
        ui_panel(c, tx, ty0, 4 * ts, th, 2 * ts, RGB(255, 255, 255), 30, RGB(255, 255, 255), 0);
        int bh = th * rows / v->count; if (bh < 4 * ts) bh = 4 * ts;
        int by = ty0 + (th - bh) * v->top / (v->count - rows);
        ui_panel(c, tx, by, 4 * ts, bh, 2 * ts, RGB(255, 230, 232), 230, RGB(255, 255, 255), 0);
    }

    // tocando agora
    ui_panel(c, px, L.nowY, pw, L.nowH, ts * 8, RGB(255, 60, 80), 46, RGB(255, 200, 205), 110);
    int ix = px + L.pad * 3, iw = pw - 6 * L.pad, y = L.nowY + ts * 6;
    char buf[320];
    if (v->playing >= 0 && v->playing < v->count) {
        snprintf(buf, sizeof buf, "%s: %s", v->paused ? "Pausado" : "Tocando", v->tracks[v->playing].name);
        ui_text(c, ix, y, ts, WHITE, buf, iw);
    } else if (v->msg && v->msg[0]) {
        ui_text(c, ix, y, ts, AMBER, v->msg, iw);
    } else {
        ui_text(c, ix, y, ts, DIM, "Nada tocando. Escolha uma faixa e aperte X.", iw);
    }
    y += line + ts * 5;
    int bh = ts * 6;
    ui_panel(c, ix, y, iw, bh, bh / 2, RGB(255, 255, 255), 40, RGB(255, 255, 255), 0);
    if (v->playing >= 0 && v->dur > 0) {
        double f = v->pos / v->dur; if (f < 0) f = 0; if (f > 1) f = 1;
        int fw = (int)(iw * f);
        if (fw > bh) ui_panel(c, ix, y, fw, bh, bh / 2, RGB(255, 80, 100), 255, RGB(255, 255, 255), 0);
        else if (fw > 0) ui_rect(c, ix, y, fw, bh, RGB(255, 80, 100));
    }
    y += bh + ts * 5;
    char t1[16], t2[16];
    fmt_time(t1, v->playing >= 0 ? v->pos : 0);
    if (v->playing >= 0 && v->dur > 0) fmt_time(t2, v->dur); else strcpy(t2, "--:--");
    snprintf(buf, sizeof buf, "%s / %s", t1, t2);
    ui_text(c, ix, y, ts, DIM, buf, 0);
    snprintf(buf, sizeof buf, "Volume %d%%", v->volume);
    ui_text(c, ix + iw - ui_text_width(buf, ts), y, ts, DIM, buf, 0);

    // legenda dos botoes
    const char *leg = "[X] Tocar   [O] Parar   [^] Pausar   [#] Atualizar   [L1/R1] Volume";
    ui_text(c, (w - ui_text_width(leg, ts)) / 2, L.footY, ts, DIM, leg, w - 2 * L.mx);
}
