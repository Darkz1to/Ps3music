// screen.h - monta a tela do player (lista de musicas + "tocando agora"). Sem dependencias do PS3.
#pragma once
#include "ui.h"

typedef struct {
    char name[200];          // nome para exibir (sem extensao)
    char path[400];          // caminho completo
    unsigned char is_mp3;    // 1 = mp3, 0 = wav
} Track;

typedef struct {
    const Track *tracks;
    int count, sel, top;     // selecao e primeira linha visivel
    int playing;             // indice da faixa tocando, -1 = nenhuma
    int paused;
    int volume;              // 0..100
    double pos, dur;         // segundos (dur <= 0 = desconhecida)
    const char *dir;         // pasta que esta sendo lida
    const char *msg;         // mensagem de status/erro (pode ser NULL)
} View;

int  screen_rows(int w, int h);              // quantas linhas cabem na lista
void screen_draw(Canvas *c, const View *v);  // desenha a tela inteira
